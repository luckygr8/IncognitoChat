package com.example.chatdemo;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.media.Image;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.messaging.FirebaseMessaging;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedList;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private String username;
    final String stringID = getRandomStringID(15);
    private FirebaseDatabase database;
    private DatabaseReference myRef;

    private int TIME_OUT=20000;

    private EditText ET;
    private RecyclerView message_area;
    private ImageView more_options;
    private ChatRecylerAdapter recycler;

    private Runnable onstop;
    private Handler handler;

    public void Init()
    {
        database=  FirebaseDatabase.getInstance();
        myRef = database.getReference();

        ET= findViewById(R.id.message);

        message_area = findViewById(R.id.message_area);
        recycler = new ChatRecylerAdapter(this);
        message_area.setLayoutManager(new LinearLayoutManager(this));;
        message_area.setAdapter(recycler);
        more_options = findViewById(R.id.more_options);

        handler = new Handler();

        onstop = new Runnable() {
            @Override
            public void run() {
                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference myRef = database.getReference();
                myRef.child(stringID).removeValue();
                finish();
            }
        };
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        setContentView(R.layout.activity_main);

        Init();

        setUpMoreOptions();

        username = getIntent().getStringExtra("username");

        myRef.child(stringID).setValue(new Message(username, ""));
        FloatingActionButton but = findViewById(R.id.but);
        but.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String messgage = ET.getText().toString().trim();
                if (messgage.isEmpty())
                    return;
                myRef.child(stringID).setValue(new Message(username, messgage));
                ET.setText("");
            }
        });

        myRef.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                Map<String, Object> mp = (Map<String, Object>) dataSnapshot.getValue();
                recycler.AddnewUser(mp.get("name").toString());
                Toast.makeText(MainActivity.this, mp.get("name").toString() + " has joined the chat", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                Map<String, Object> mp = (Map<String, Object>) dataSnapshot.getValue();
                String sendername = mp.get("name").toString();
                String message = mp.get("message").toString();
                Date date = Calendar.getInstance().getTime();
                SimpleDateFormat sdf = new SimpleDateFormat("hh.mm");
                String time = sdf.format(date);
                if(sendername.equals(username))
                {
                    recycler.AddIntoMessageList(new You(message,time));
                }
                else
                {
                    recycler.AddIntoMessageList(new Sender(sendername,message,time));
                }
            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
                Map<String, Object> mp = (Map<String, Object>) dataSnapshot.getValue();
                Toast.makeText(MainActivity.this, mp.get("name").toString() + " left the chat", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }



    public String getRandomStringID(int n) {

        String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                + "0123456789"
                + "abcdefghijklmnopqrstuvxyz";

        StringBuilder sb = new StringBuilder(n);

        for (int i = 0; i < n; i++) {

            int index
                    = (int) (AlphaNumericString.length()
                    * Math.random());

            sb.append(AlphaNumericString
                    .charAt(index));
        }

        return sb.toString();
    }

    private boolean doubleBackToExitPressedOnce = false;

    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "press back again to log out and exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce=false;
            }
        }, 2000);
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.removeCallbacks(onstop);

    }

    @Override
    protected void onStop() {
        super.onStop();
        Toast.makeText(this, "the app will sign you out automatically in "+TIME_OUT/1000+" seconds", Toast.LENGTH_LONG).show();
        handler.postDelayed(onstop,TIME_OUT);
    }

    public void setUpMoreOptions()
    {
        more_options.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu popupMenu = new PopupMenu(MainActivity.this,v);
                MenuInflater inflater = popupMenu.getMenuInflater();
                inflater.inflate(R.menu.options, popupMenu.getMenu());

                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {

                        switch (item.getItemId())
                        {
                            case R.id.op1:
                                Toast.makeText(MainActivity.this, "option 1", Toast.LENGTH_SHORT).show();
                                break;

                            case R.id.op2:
                                Toast.makeText(MainActivity.this, "option 2", Toast.LENGTH_SHORT).show();
                                break;
                        }

                        return true;
                    }
                });

                popupMenu.show();
            }
        });
    }

}

/*if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O)
        {
            NotificationChannel channel = new NotificationChannel("chatnotif","Notification", NotificationManager.IMPORTANCE_DEFAULT);

            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }*/

        /*FirebaseMessaging.getInstance().subscribeToTopic("chatnotif")
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        String msg = "success";
                        if (!task.isSuccessful()) {
                            msg = "unsuccessful";
                        }
                        Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
                    }
                });*/