package com.example.chatdemo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SignInactivity extends AppCompatActivity {

    private final FirebaseAuth mAuth = FirebaseAuth.getInstance();
    private FirebaseAuth.AuthStateListener mauthStateListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        MaterialButton join = findViewById(R.id.join);
        final TextInputEditText email = findViewById(R.id.email);
        final TextInputEditText password = findViewById(R.id.password);
        final TextView signup = findViewById(R.id.signup);

        /*mauthStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                if(firebaseAuth.getCurrentUser()!=null)
                {

                }
            }
        };*/

        join.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String useremail = email.getText().toString().trim();
                String userpass = password.getText().toString().trim();

                if (useremail.isEmpty() || userpass.isEmpty()) {
                    Toast.makeText(SignInactivity.this, "please fill out all the fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                mAuth.signInWithEmailAndPassword(useremail, userpass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {

                            FirebaseUser user = mAuth.getCurrentUser();
                            String nickname = new LocalDB(SignInactivity.this).getnickname(user.getEmail());
                            openMain(nickname);
                        } else {
                            Exception e = task.getException();
                            if (e instanceof FirebaseAuthException) {
                                String code = ((FirebaseAuthException) e).getErrorCode();
                                String message = "";
                                switch (code) {
                                    case "ERROR_EMAIL_ALREADY_IN_USE":
                                        message = "email already exists";
                                        break;
                                    case "ERROR_WRONG_PASSWORD":
                                        message = "email and password dont match";
                                        break;
                                    case "ERROR_WEAK_PASSWORD":
                                        message = "password seems too weak , try again";
                                        break;
                                    case "ERROR_INVALID_EMAIL":
                                        message="email is badly formatted";
                                        break;
                                    case "ERROR_ACCOUNT_EXISTS_WITH_DIFFERENT_CREDENTIAL":
                                        message = "account exists with different credentials";
                                        break;
                                    case "ERROR_USER_DISABLED":
                                        message="The user account has been disabled by an administrator";
                                        break;
                                    default:
                                        message = "Authentication failed";
                                }
                                Toast.makeText(SignInactivity.this, message, Toast.LENGTH_SHORT).show();
                            }

                        }
                    }
                });
            }
        });

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SignInactivity.this, Signupactivity.class));
            }
        });
    }

    public void openMain(String username) {
        Intent intent = new Intent(SignInactivity.this, MainActivity.class);
        intent.putExtra("username", username);
        startActivity(intent);
        finish();
    }
}
