package com.example.chatdemo;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class LocalDB {
    private final String DB_NAME = "incogchat";

    private final String TABLE = "CREATE TABLE IF NOT EXISTS incog ( id INTEGER PRIMARY KEY AUTOINCREMENT , email TEXT UNIQUE , nickname TEXT)";

    private SQLiteDatabase db ;
    private Context context;

    public LocalDB(Context context)
    {
        this.context = context;
        try{
            db = context.openOrCreateDatabase(DB_NAME,Context.MODE_PRIVATE,null);
            db.setForeignKeyConstraintsEnabled(true);
            db.execSQL(TABLE);
        }catch (Exception e){
            e.printStackTrace(System.out);
        }
    }

    public boolean AddNickname(String email , String nickname)
    {
        try
        {
            String query = "INSERT INTO incog(email,nickname) VALUES('"+email+"','"+nickname+"')";
            db.execSQL(query);
        }catch (Exception e)
        {
            return false;
        }
        finally {
            db.close();
        }
        return true;
    }

    public String getnickname(String email)
    {
        try{

            String query = "SELECT nickname FROM incog WHERE email = '"+email+"'";

            Cursor c = db.rawQuery(query,null);

            c.moveToFirst();

            if(c.getCount() !=0)
            {
                int nickname = c.getColumnIndex("nickname");

                return c.getString(nickname);

            }

        }catch (Exception e){
            e.printStackTrace(System.out);

        }
        finally {
            db.close();
        }

        return null;
    }
}
